import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper5 extends Mapper<key, value, Text, DoubleWritable>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		String month = inpv.getmonth();
		double val = inpv.getAmt();
		c.write(new Text(month),new DoubleWritable(val));
}
}
