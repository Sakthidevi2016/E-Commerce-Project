import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

public class recordreader extends RecordReader {
	key kobj;
	value val;
	LineRecordReader reader = new LineRecordReader();

	@Override
	public void close() throws IOException {
		reader.close();		
	}

	@Override
	public Object getCurrentKey() throws IOException, InterruptedException {
		return kobj;
	}

	@Override
	public Object getCurrentValue() throws IOException, InterruptedException {
		return val;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return reader.getProgress();
	}

	@Override
	public void initialize(InputSplit arg0, TaskAttemptContext arg1) throws IOException, InterruptedException {
		reader.initialize(arg0, arg1);
		
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		boolean getnextVal = reader.nextKeyValue();
		if(getnextVal){
			if(kobj == null)
				kobj = new key();
			if(val == null)
				val = new value();
			org.apache.hadoop.io.Text line = reader.getCurrentValue();
			String[] each = line.toString().split(",");
			kobj.setid(new Text(each[2]));
			String month[] = each[1].split("-");
			val.setmonth(new Text(month[0]));
			val.setAmt(new Text(each[3]));
			val.settid(new Text(each[0]));
			val.setcategory(new Text(each[4]));
			val.setproduct(new Text(each[5]));
			val.setcity(new Text(each[6]));
			val.setstate(new Text(each[7]));
			val.setpayment(new Text(each[8]));
		}
		else{
			kobj = null;
			val = null;	
		}
		return getnextVal;
	}

}
