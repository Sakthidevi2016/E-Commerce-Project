import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper6 extends Mapper<key, value, DoubleWritable, Text>{
	public void map(key inpk, value inpv, Context c) throws IOException, InterruptedException{
		double val = inpv.getAmt();
		c.write(new DoubleWritable(val),new Text(inpv.gettid()+" "+inpk.getid()+" "+inpv.getmonth()+" "+inpv.getcategory()+" "+inpv.getproduct()+" "+inpv.getcity()
		+" "+inpv.getstate()+" "+inpv.getpayment()));
}
}
