import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class reducer6 extends Reducer<DoubleWritable, Text, DoubleWritable, Text>{
    public void reduce(Iterable<DoubleWritable> inpk, Text inpv, Context c) throws IOException, InterruptedException{
    	     	   for(DoubleWritable x: inpk)
    	     		   c.write(x, inpv);
    	    	    		   
       }
   }
