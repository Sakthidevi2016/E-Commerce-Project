import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Scanner src = new Scanner(System.in);
		System.out.println("Enter your task");
		int task = src.nextInt();
		switch(task){
		case 1:
			Configuration conf = new Configuration();
			System.out.println("Enter the minimum value");
			int amt = src.nextInt();
			conf.setInt("Amount", amt);
			Job j = new Job(conf, "Output");
			FileSystem hdfs = FileSystem.get(conf);
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper1.class);
			j.setNumReduceTasks(0);
			j.setMapOutputKeyClass(Text.class);
			j.setMapOutputValueClass(DoubleWritable.class);
			j.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path (args[1]));
		
			Path newpath = new Path(args[1]);
			if(hdfs.exists(newpath)){
				hdfs.delete(newpath,true);
			}
			Path localfilepath = new Path("/home/hduser/InputFormat_Trans1");
			if(j.waitForCompletion(true)){
				hdfs.copyToLocalFile(newpath, localfilepath);
			}
		
			System.exit(j.waitForCompletion(true)?0:1);
		break;
		case 2:
			Configuration conf1 = new Configuration();
			System.out.println("Enter the minimum value");
			int lamt = src.nextInt();
			System.out.println("Enter the minimum value");
			int uamt = src.nextInt();
			conf1.setInt("Lower", lamt);
			conf1.setInt("Upper", uamt);
			Job j1 = new Job(conf1, "Output");
			FileSystem hdfs1 = FileSystem.get(conf1);
			j1.setJarByClass(driver.class);
			j1.setMapperClass(mapper2.class);
			j1.setReducerClass(reducer2.class);
			j1.setNumReduceTasks(1);
			j1.setMapOutputKeyClass(Text.class);
			j1.setMapOutputValueClass(IntWritable.class);
			j1.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j1, new Path(args[0]));
			FileOutputFormat.setOutputPath(j1, new Path (args[1]));
			
			Path newpath1 = new Path(args[1]);
			if(hdfs1.exists(newpath1)){
				hdfs1.delete(newpath1,true);
			}
			Path localfilepath1 = new Path("/home/hduser/InputFormat_Trans2");
			if(j1.waitForCompletion(true)){
				hdfs1.copyToLocalFile(newpath1, localfilepath1);
			}
			
			System.exit(j1.waitForCompletion(true)?0:1);	
		break;
		case 3:
			Configuration conf2 = new Configuration();
			FileSystem hdfs2 = FileSystem.get(conf2);
			System.out.println("Enter the user id");
			int uid = src.nextInt();
			conf2.setInt("User id", uid);
			Job j2 = new Job(conf2, "Output");
			j2.setJarByClass(driver.class);
			j2.setMapperClass(mapper3.class);
			j2.setReducerClass(reducer3.class);
			j2.setNumReduceTasks(1);
			j2.setMapOutputKeyClass(Text.class);
			j2.setMapOutputValueClass(DoubleWritable.class);
			j2.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j2, new Path(args[0]));
			FileOutputFormat.setOutputPath(j2, new Path (args[1]));

			Path newpath2 = new Path(args[1]);
			if(hdfs2.exists(newpath2)){
				hdfs2.delete(newpath2,true);
			}
			
			Path localfilepath2 = new Path("/home/hduser/InputFormat_Trans3");
			if(j2.waitForCompletion(true)){
				hdfs2.copyToLocalFile(newpath2, localfilepath2);
			}
				System.exit(j2.waitForCompletion(true)?0:1);
		break;
		case 4:
			Configuration conf3 = new Configuration();
			FileSystem hdfs3 = FileSystem.get(conf3);
			conf3.setInt("Month", 1);
			Job j3 = new Job(conf3, "Output");
			j3.setJarByClass(driver.class);
			j3.setMapperClass(mapper4.class);
			j3.setReducerClass(reducer4.class);
			j3.setNumReduceTasks(1);
			j3.setMapOutputKeyClass(Text.class);
			j3.setMapOutputValueClass(DoubleWritable.class);
			j3.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j3, new Path(args[0]));
			FileOutputFormat.setOutputPath(j3, new Path (args[1]));

			Path newpath3 = new Path(args[1]);
			if(hdfs3.exists(newpath3)){
				hdfs3.delete(newpath3,true);
			}
			
			Path localfilepath3 = new Path("/home/hduser/InputFormat_Trans4");
			if(j3.waitForCompletion(true)){
				hdfs3.copyToLocalFile(newpath3, localfilepath3);
			}
				System.exit(j3.waitForCompletion(true)?0:1);
		break;
		case 5:
			Configuration conf4 = new Configuration();
			FileSystem hdfs4 = FileSystem.get(conf4);
			conf4.setInt("Partitioner", 12);
			Job j4 = new Job(conf4, "Output");
			j4.setJarByClass(driver.class);
			j4.setMapperClass(mapper5.class);
			j4.setReducerClass(reducer5.class);
			j4.setPartitionerClass(partitioner5.class);
			j4.setNumReduceTasks(12);
			j4.setMapOutputKeyClass(Text.class);
			j4.setMapOutputValueClass(DoubleWritable.class);
			j4.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j4, new Path(args[0]));
			FileOutputFormat.setOutputPath(j4, new Path (args[1]));

			Path newpath4 = new Path(args[1]);
			if(hdfs4.exists(newpath4)){
				hdfs4.delete(newpath4,true);
			}
			
			Path localfilepath4 = new Path("/home/hduser/InputFormat_Trans5");
			if(j4.waitForCompletion(true)){
				hdfs4.copyToLocalFile(newpath4, localfilepath4);
			}
				System.exit(j4.waitForCompletion(true)?0:1);
		break;
		case 6:
			Configuration conf5 = new Configuration();
			FileSystem hdfs5 = FileSystem.get(conf5);
			conf5.setInt("Partitioner", 12);
			Job j5 = new Job(conf5, "Output");
			j5.setJarByClass(driver.class);
			j5.setMapperClass(mapper6.class);
			j5.setReducerClass(reducer6.class);
			j5.setNumReduceTasks(1);
			j5.setMapOutputKeyClass(DoubleWritable.class);
			j5.setMapOutputValueClass(Text.class);
			j5.setInputFormatClass(inputformat.class);
		
			FileInputFormat.addInputPath(j5, new Path(args[0]));
			FileOutputFormat.setOutputPath(j5, new Path (args[1]));

			Path newpath5 = new Path(args[1]);
			if(hdfs5.exists(newpath5)){
				hdfs5.delete(newpath5,true);
			}
			
			Path localfilepath5 = new Path("/home/hduser/InputFormat_Trans6");
			if(j5.waitForCompletion(true)){
				hdfs5.copyToLocalFile(newpath5, localfilepath5);
			}
				System.exit(j5.waitForCompletion(true)?0:1);
		break;
		}
	}
}